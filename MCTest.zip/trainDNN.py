import sys
import numpy
import timeit

from DeepNNet import DNN
from parseData import *

def my_print(epoch, ith_batch, n_batch, cost):
	sys.stdout.write("\repoch %i, batch: %i/%i, cost: %f" % \
				(epoch, ith_batch, n_batch, cost))
	sys.stdout.flush()

def main():

	print "loading data..."
	#raw_train_img, raw_val_img, raw_test_img = load_mnist(dataset="all")
	#train_img, raw_train_label = raw_train_img[0], raw_train_img[1]
	#val_img, raw_val_label = raw_val_img[0], raw_val_img[1]
	#test_img, raw_test_label = raw_test_img[0], raw_test_img[1]

	#train_label = mk_mnist_label(raw_train_label)
	#val_label = mk_mnist_label(raw_val_label)
	#test_label = mk_mnist_label(raw_test_label)

	#batch_size = 100
	#print "training data..."
	#batch_train_data, batch_train_label = \
	#	mk_batch(train_img, batch_size, train_label)
	#print "validation data..."
	#batch_val_data, batch_val_label = \
	#	mk_batch(val_img, batch_size, val_label)
	#print "testing data..."
	#batch_test_data, batch_test_label = \
	#	mk_batch(test_img, batch_size, test_label, shuffle=False)

	train_data, tr_name = read_fbank_data("fbank/normal_valid.ark")
	val_data, val_name = read_fbank_data("fbank/normal_valid.ark")
	test_data, te_name = read_fbank_data("fbank/normal_test.ark")
	
	lab = read_fbank_data("label/train.lab", dataset="label")
	ph = read_fbank_data("phones/48_39.map", dataset="phones")
	en_lab = encode_1ofN(ph["phones_48"], N=48, label=lab)
	
	train_label = mk_fbank_label(en_lab, tr_name)
	val_label = mk_fbank_label(en_lab, val_name)
	
	batch_size = 128
	print "making batch --- training data..."
	batch_train_data, batch_train_label = \
		mk_batch(train_data, batch_size, train_label)
	print "making batch --- validation data..."
	batch_val_data, batch_val_label = \
		mk_batch(val_data, batch_size, val_label)
	print "making batch --- testing data..."
	batch_test_data = mk_test_batch(test_data, batch_size)
	batch_te_name = mk_name_batch(te_name, batch_size)
	
	print "training started..."
	start_time = timeit.default_timer()
	
	dnn = DNN(
		input_dim=69,
		hid_layer_dim=1024,
		output_dim=48,
		batch_size=batch_size
		#pre_train="trained_w_rbm/rbm_trained_epoch_40.pkl"
	)

	training_epochs = 2
	n_batch = len(batch_train_data)
	for epoch in range(1, training_epochs+1):
		for j in range(n_batch):
			cost = dnn.train(batch_train_data[j], batch_train_label[j])
			if(epoch == 1): dnn.first = False
			my_print(epoch, j+1, n_batch, cost)
			#if(np.count_nonzero(cost[0]) != 128):
			#	print j
			#print "w1:\n", cost[1]
			#print "w2:\n", cost[2]
			#print "w3:\n", cost[3]
			#print "w5:\n", cost[4]
		# validation
		acc_val = 0.0
		if(epoch%1 == 0):
			for j in range(len(batch_val_data)):
				acc_val += (dnn.valid(batch_val_data[j], batch_val_label[j])) \
							/len(val_data)#/len(val_img))
			print(", acurracy: %f" % acc_val)

		"""for mnist dataset"""
		#if(epoch%10 == 0):
		#	print "==========================testing=========================="
		#	acc_test = 0.0
		#	for j in range(len(batch_test_data)):
		#		acc_test += (dnn.valid(batch_test_data[j], batch_test_label[j]) \
		#					/len(test_img))
		#	print("acurracy of testing data: %f" % acc_test)
		#	print "saving trained weights...\n"
		#	dnn.save_weights("trained_w_dnn/dnn_rbm_trained_epoch_"+str(epoch))
		"""for fbank dataset"""
		if(epoch%1 == 0):
			for j in range(len(batch_test_data)):
				batch_test_predict = dnn.test(batch_test_data[j])
				mk_speech_csv(batch_test_predict, batch_te_name[j], \
							ph["39_phones"])
		"""early stoping"""
		#if(epoch%50 == 0):
		#	go_on = raw_input("Keep training...?(yes/no)")
		#	if(go_on == "no"):
		#		break

	print "training finished..."

	end_time = timeit.default_timer()
	training_time = end_time - start_time
	print ("training took %f minutes" % (training_time/60.))


if __name__ == '__main__':
	main()


