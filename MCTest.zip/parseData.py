import csv
import random
import cPickle
import numpy as np

"""mnist data"""

def load_mnist(dataset="train"):
    mnist_data = open("data/mnist.pkl")
    train_data, val_data, test_data = cPickle.load(mnist_data)
    if(dataset == "train"):
        return train_data, val_data
    elif(dataset == "test"):
        return test_data
    elif(dataset == "all"):
    	return train_data, val_data, test_data
    else:
        raise ValueError("dataset must be 'train', 'test', or 'all'...")

def mk_mnist_label(raw_data_label):
	label_size = len(raw_data_label)
	data_label = np.zeros((label_size, 10))
	for i in range(label_size):
		label_vec = np.zeros(10)
		label_vec[raw_data_label[i]] = 1
		data_label[i, :] = label_vec
	return data_label


def mk_batch(data_all, batch_size, data_label=None, shuffle=True):
	data_size = len(data_all[0])
	data_num = len(data_all)
	print "total data: %d" % data_num
	print "data size:  %d" % data_size
	n_batch = data_num/batch_size
	n_left_data = data_num % batch_size
	if(n_left_data != 0):
		n_batch += 1
	batch_data = np.zeros((n_batch, batch_size, data_size))

	if data_label is not None:
		label_size = len(data_label[0])
		batch_label = np.zeros((n_batch, batch_size, label_size))
		data_label_shuf = np.zeros((data_num, label_size))

	if(shuffle):
		data_all_shuf = np.zeros((data_num, data_size))
		idx_shuffle = np.arange(data_num)
		np.random.shuffle(idx_shuffle)
		k=0
		for idx in idx_shuffle:
			data_all_shuf[k, :] = data_all[idx]
			if data_label is not None:
				data_label_shuf[k] = data_label[idx]
			k+=1
	else:
		data_all_shuf = data_all
		if data_label is not None:
			data_label_shuf = data_label

	if(n_left_data != 0):
		for i in range(batch_size - n_left_data):
			data_all_shuf = np.concatenate((data_all_shuf, 
						np.asarray([data_all_shuf[i]])))
			data_label_shuf = np.concatenate((data_label_shuf, 
						np.asarray([data_label_shuf[i]])))

	for i in range(n_batch):
		batch_data_matrix = np.zeros((batch_size, data_size))
		if data_label is not None:
			batch_label_matrix = np.zeros((batch_size, label_size))
		for j in range(batch_size):
			idx = j + i * batch_size
			batch_data_matrix[j, :] = data_all_shuf[idx]
			if data_label is not None:
				batch_label_matrix[j, :] = data_label_shuf[idx]
		batch_data[i, :] = batch_data_matrix
		if data_label is not None:
			batch_label[i, :] = batch_label_matrix
	if data_label is not None:
		return batch_data, batch_label
	else:
		return batch_data

def mk_test_batch(data_all, batch_size):
	data_size = len(data_all[0])
	data_num = len(data_all)
	print "total data: %d" % data_num
	print "data size:  %d" % data_size
	n_batch = data_num/batch_size + 1

	n_left_data = data_num % batch_size
	batch_data = []
	for i in range(n_batch):
		if(i == n_batch-1):
			if(n_left_data != 0):
				batch_size = n_left_data
			else: break
		temp = []
		for j in range(batch_size):
			temp.append(data_all[j + i * batch_size])
		batch_data.append(temp)
		del temp
	np_batch_data = np.array(batch_data)
	del batch_data
	return np_batch_data

"""fbank/mfcc data"""

def read_fbank_data(file_name, dataset="speech"):
	f = open(file_name)
	if(dataset == "speech"):
		data = []
		name = []
		for line in f:
			temp = line.split()
			name.append(temp[0])
			data.append(temp[1:])
		del temp
		return data, name
	elif(dataset == "label"):
		label_dict = {}
		for line in f:
			temp = line.split(",")
			label_dict[temp[0]] = temp[1][:-1]
		del temp
		return label_dict
	elif(dataset == "phones"):
		phones_dict = {"phones_48": {}, "39_phones":{}, \
						"48_39_map": {}}
		i=0
		for line in f:
			temp = line.split()
			phones_dict["phones_48"][temp[0]] = i
			phones_dict["39_phones"][i] = temp[1]
			phones_dict["48_39_map"][temp[0]] = temp[1]
			i+=1
		del temp
		return phones_dict
	else:
		raise ValueError("dataset must be 'speech', 'label', or 'phones'...")

def encode_1ofN(code_map, N, label):
	encode_label = {}
	one_of_N = []
	for k, v in label.items():
		one_of_N = [0]*47
		one_of_N.insert(code_map[v], 1)
		encode_label[k] = one_of_N
	return encode_label

def mk_fbank_label(raw_data_label, name):
	n_label = len(name)
	data_label = np.zeros((n_label, 48))
	for i in range(n_label):
		data_label[i, :] = raw_data_label[name[i]]
	return data_label

def mk_name_batch(name, batch_size):
	name_num = len(name)
	n_batch = name_num/batch_size + 1

	n_left_name = name_num % batch_size
	batch_name = []
	for i in range(n_batch):
		if(i == n_batch-1):
			if(n_left_name != 0):
				batch_size = n_left_name
			else: break
		temp = []
		for j in range(batch_size):
			temp.append(name[j + i * batch_size])
		batch_name.append(temp)
		del temp
	return batch_name

def mk_speech_csv(y_predict, batch_te_name, idx_phones_map):
	for i in range(len(y_predict)):
		with open("output.csv", 'a') as csvfile:
			fieldnames = ["Id", "Prediction"]
			writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
			writer.writerow({
				"Id": batch_te_name[i],
				"Prediction": idx_phones_map[np.argmax(y_predict[i])]
			})

def load_fbank():
	pass

if __name__ == "__main__":
	train_data, tr_name = read_fbank_data("fbank/normal_train.ark")
	val_data, val_name = read_fbank_data("fbank/normal_valid.ark")
	test_data, te_name = read_fbank_data("fbank/normal_test.ark")
	
	lab = read_fbank_data("label/train.lab", dataset="label")
	ph = read_fbank_data("phones/48_39.map", dataset="phones")
	en_lab = encode_1ofN(ph["phones_48"], N=48, label=lab)
	
	train_label = mk_fbank_label(en_lab, tr_name)
	val_label = mk_fbank_label(en_lab, val_name)

	#data_all = ([train_data, train_label], \
	#			[val_data, val_label],
	#			[test_data, te_name])
	#cPickle.dump(data_all, open("data/fbank.pkl", "wb"))




